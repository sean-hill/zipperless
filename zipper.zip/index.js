const lodash = require('lodash')

console.log('5 + 5 =', lodash.add(5, 5))
